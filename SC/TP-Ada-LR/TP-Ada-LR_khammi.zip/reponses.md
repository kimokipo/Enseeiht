Problème des Lecteus et Redacteurs. Version ADA
========================

Reponses

- Le fichier `lr-synchro-basique_pas_priorite.adb` contient l'implantation par la méthode des Automates, et Sans priorité.

- Le fichier `lr-synchro-exclusion_pas_priorite.adb` contient l'implantation de la tâche serveur sans priorité.

- Le fichier `lr-synchro-basique_priorite_redacteurs.adb` contient l'implantation par la méthode des Automates, et avec priorité aux Redacteurs.

- Le fichier `lr-synchro-exclusion_priorite_redacteurs.adb` contient l'implantation de la tâche serveur, et avec priorité aux Redacteurs.

- Le fichier `lr-synchro-basique_fifo.adb` contient l'implantation par la méthode des Automates avec la stratégie FIFO.

- Le fichier `lr-synchro-exclusion_fifo.adb` contient l'implantation de la tâche serveur avec la stratégie FIFO.
