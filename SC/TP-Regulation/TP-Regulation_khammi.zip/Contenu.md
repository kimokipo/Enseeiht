- comptage des mots d'un répertoire : find+grep (versions fork/join et récursive)
- données : tableaux générés pat GCVT (non intégrés à l'archive)
- exemples énoncé : contient le source des exemples de l'énoncé, avec des variantes complémentaires
 (FJG : exemple ForkJoin, pool fixe : exemple somme)
- README.html : sujet (format html)
- README.md :  : sujet (format markdown)
- max : calcul du maximum d'un tableau (mono, pool, forkjoin) 
		+ utilitaire de gestion de tableaux (GCVT)
- tri fusion : (mono, pool, forkjoin) 