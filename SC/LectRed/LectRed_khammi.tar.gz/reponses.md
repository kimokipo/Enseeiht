Problème des Lecteus et Redacteurs.
========================

Reponses

- Le fichier `LectRed_PrioLecteur.java` contient l'implantation qui donne la priorité aux Lecteurs en utilisant deux variables conditions `PL` et `PE` et un variable entier `lecteur_att` qui compte le nombre de lecteurs en attente.

- Le fichier `LectRed_PrioRedacteur.java` contient l'implantation qui donne la priorité aux Redacteurs en utilisant deux variables conditions `PL` et `PE` et un variable entier `redacteur_att` qui compte le nombre de redacteurs en attente.

- Le fichier `LectRed_Equite.java` contient l'implantation de la solution équitable en utilisant deux variables conditions `Attente` et `Sas` et deux files d'attentes `FileDemandeurs` et `FileRedacteurs`, qui sauvent les nom des Threads Lecteur ou Redacteur.


