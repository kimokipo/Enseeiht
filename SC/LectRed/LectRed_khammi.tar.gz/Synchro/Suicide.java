// Time-stamp: <02 mai 2013 10:16 queinnec@enseeiht.fr>

package Synchro;

@SuppressWarnings("serial")
public class Suicide extends RuntimeException
{
}
