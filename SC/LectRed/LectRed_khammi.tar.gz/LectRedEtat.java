// Time-stamp: <24 fév 2010 09:41 queinnec@enseeiht.fr>

public enum LectRedEtat {
    Redacteur_Demande,
      Redacteur_Ecrit,
      Redacteur_Rien,
      Lecteur_Demande,
      Lecteur_Lit,
      Lecteur_Rien
}	
