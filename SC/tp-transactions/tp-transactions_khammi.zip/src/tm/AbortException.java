package tm;

// L'exception vérifiée qui permet d'interrompre
// une transaction pour l'annuler proprement.
public class AbortException extends Exception {}
