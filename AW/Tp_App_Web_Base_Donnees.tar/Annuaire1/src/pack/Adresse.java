package pack;

import javax.persistence.*;

@Entity
public class Adresse {
	
	private String rue;
	private String ville;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	@ManyToOne
	Personne owner;
	
	public Personne getOwner() {
		return owner;
	}


	public void setOwner(Personne owner) {
		this.owner = owner;
	}


	public Adresse() {}
	
	
	public Adresse(String rue, String ville) {
		this.rue = rue;
		this.ville = ville;
	}
	
	public String getRue() {
		return rue;
	}

	public void setRue(String rue) {
		this.rue = rue;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	
}
