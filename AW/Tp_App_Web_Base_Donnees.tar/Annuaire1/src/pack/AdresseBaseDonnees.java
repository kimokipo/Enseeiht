package pack;

import javax.persistence.*;

@Entity
public class AdresseBaseDonnees {
	
	private String rue;
	private String ville;
	private Integer id;
	
	
	public Adresse(String rue, String ville, int id) {
		this.rue = rue;
		this.ville = ville;
		this.id = id;
	}
	
	public String getRue() {
		return rue;
	}

	public void setRue(String rue) {
		this.rue = rue;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	
}
