function ecarx = Ecart_type (x)
    varx= Variance (x);
    ecarx= varx^(0.5);
end 