function xbar = Moyenne(x)
   n=length(x);
   xbar=(1/n)*(ones(1,n)*x);
   
end