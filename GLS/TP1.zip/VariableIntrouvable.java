
public class VariableIntrouvable extends RuntimeException {

}
