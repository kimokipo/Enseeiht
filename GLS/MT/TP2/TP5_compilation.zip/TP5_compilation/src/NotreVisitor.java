import javax.lang.model.element.*;
import javax.lang.model.util.ElementKindVisitor8;

public class NotreVisitor extends ElementKindVisitor8<Void,Void>  {

	@Override
	public Void visitType(TypeElement e, Void p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Void visitVariable(VariableElement e, Void p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Void visitExecutable(ExecutableElement e, Void p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Void visitTypeParameter(TypeParameterElement e, Void p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Void visitUnknown(Element e, Void p) {
		// TODO Auto-generated method stub
		return null;
	
	}
}
