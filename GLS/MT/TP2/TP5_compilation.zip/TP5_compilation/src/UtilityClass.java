@Utility
final public class UtilityClass {
	private UtilityClass() {}
	public static void m1() { }
	public static void m2() { }
}
