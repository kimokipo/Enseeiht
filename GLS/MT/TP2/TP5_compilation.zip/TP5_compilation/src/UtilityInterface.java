@Utility
public interface UtilityInterface {
	void m();
	int i = 0;
}
