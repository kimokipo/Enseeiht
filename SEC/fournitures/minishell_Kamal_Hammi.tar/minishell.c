#include <stdio.h>    /* printf */
#include <string.h>
#include  <unistd.h>/* fork */
#include <stdlib.h>   /* EXIT_SUCCESS */
#include  <sys/wait.h>/* wait */
#include  "readcmd.h"

struct cmdline * commande;


struct liste_pids
{
    pid_t pid;
    int etat; //etat = 0 -> terminé, etat = 1 -> suspendu, etat = 2 -> actif 
    char commande_lancee[10];
};

typedef struct liste_pids liste_pids ;
liste_pids tableau_pids[10];

pid_t pidFils1, pidFils2 , idFils2;
int idFils1 = 0;

void ajouter_pid (int id, pid_t pid, int etat, char * commande_lancee){
	tableau_pids[id-1].pid =pid;
	tableau_pids[id-1].etat = etat;
	strcpy(tableau_pids[id-1].commande_lancee, commande_lancee);
}


void changer_etat (int id, int nouveletat){
	tableau_pids[id-1].etat = nouveletat;
}

int get_id (pid_t pid){
	int id = -1;
	for (int i=0 ;i<10;i++){
		if(tableau_pids[i].pid == pid){
			id = i+1;
		}
	}
	return id;
}

void handler_chld(int signal_num) {
    int fils_termine, wstatus ;
     if (signal_num == SIGCHLD) {
        while ((fils_termine = (int) waitpid(-1, &wstatus, WNOHANG | WUNTRACED | WCONTINUED)) > 0) {
		int id = get_id(fils_termine);
           if (WIFEXITED(wstatus) |  WIFSIGNALED(wstatus)){
		
               changer_etat (id,0);
           }
           else if (WIFSTOPPED(wstatus)) {
            
		changer_etat (id,1);
           }else {	
			changer_etat (id,2);	
	      
           }
        }
     }
     
}

void handler_int(int num){
	kill(pidFils1,SIGINT);
	changer_etat (idFils1,0);
}
	
void handler_Stop(int num){
	kill(pidFils1,SIGSTOP);
	changer_etat (idFils1,1);
}


int main(int argc,char *argv[]) {
		
		sigset_t *ens = NULL;
	    	sigemptyset(ens);
	    	sigaddset(ens,SIGINT);
		signal(SIGINT,handler_int);
		signal(SIGCHLD,handler_chld); 
		sigprocmask (SIG_BLOCK, ens, NULL);
		sigemptyset(ens);
	    	sigaddset(ens,SIGTSTP);
		sigaddset(ens,SIGSTOP);
		signal(SIGTSTP,handler_Stop);
		signal(SIGSTOP,handler_Stop);
		sigprocmask (SIG_BLOCK, ens, NULL);
		printf(">>>");
  	while(1) {

	
		int  codeTerm2;
		 /* la  commande  saisie  au  clavier  */
		char path[35] = "/bin/";
		char path_grounded[35] = "/bin/";
		
		commande = readcmd();   /* lit et  range  dans commande la  chaine  entrée au  clavier */
		if (strcmp(commande->seq[0][0],"cd") == 0) {
			if((commande->seq[0][1] ==NULL) || (strcmp(commande->seq[0][1],"~")) ){
				chdir("/");
			}else{
				chdir(commande->seq[0][1]);
			}
		}else if ((strcmp(commande->seq[0][0],"jobs") == 0)){
			for(int i = 0;i<10;i++){
					
					if (tableau_pids[i].etat != 0){
						char etat[10] = "";
						if(tableau_pids[i].etat == 2){
						 	strcpy(etat,"actif");
						}else{
							strcpy(etat,"suspendu");
						}
						printf("le processus d'idantifiant %d de pid %d est %s de commande lancée %s\n"
							,i+1,tableau_pids[i].pid,etat,tableau_pids[i].commande_lancee);
					}


			}
		
		}else if (strcmp(commande->seq[0][0],"stop") == 0){
			int id = atoi(commande->seq[0][1]);
			kill(tableau_pids[id-1].pid,SIGSTOP);

		}else if (strcmp(commande->seq[0][0],"fg") == 0){
			int id = atoi(commande->seq[0][1]);
			kill(tableau_pids[id-1].pid,SIGCONT);

		}else if (strcmp(commande->seq[0][0],"bg") == 0){
			int id = atoi(commande->seq[0][1]);
			changer_etat (id,0);
			execlp("bg","bg",(char)tableau_pids[id-1].pid,NULL);

		}else if (strcmp(commande->seq[0][0],"exit") != 0 ){

			pidFils1 = fork();
			idFils1 = idFils1+1;
			if (pidFils1  ==  -1) {
				printf("Erreur fork\n");
				exit (1);
			}

			if (pidFils1  == 0) {/* fils1 */
				strcat(path, commande->seq[0][0]);
				
				sleep(20);
				execvp(path,commande->seq[0]);
				
				pidFils2 = fork();
			
				if (pidFils2  ==  -1) {
					printf("Erreur fork\n");
					exit (1);
				}

				if (pidFils2  == 0) {/* fils2 */
					
					strcat(path_grounded, &commande->backgrounded[0]);
					execvp(path_grounded, &commande->backgrounded);
					
		     			perror("ECHEC de la commande en tache de fond");
					exit(2);

				}else {/* p`ere2 */
					idFils2 = wait(& codeTerm2 );
					if (idFils2  ==  -1) {
						perror("wait ");
						exit (3);
					}

					if (codeTerm2 == 0) {
						printf("SUCCESS dans la commande en tache de fond \n");
					}
				}

	     			perror("ECHEC");
				exit(1);

			}else{
				ajouter_pid (idFils1,pidFils1, 2,*(commande->seq[0]));
			}
		}else{
			break;
		}
		printf(">>>");
	}
  	return EXIT_SUCCESS;
}
