#include <stdio.h>    /* printf */
#include <string.h>
#include  <unistd.h>/* fork */
#include <stdlib.h>   /* EXIT_SUCCESS */
#include <fcntl.h>



pid_t pidFils1, pidFils2 , idFils2;
int idFils1 = 0;


int main(int argc,char *argv[]) {
		
		
  	
				
			
				int p[2];
				int q[2];
				
				pipe(p);
				pidFils1 = fork();
				if (pidFils1  ==  -1) {
					printf("Erreur fork\n");
					exit (1);
				}

				if (pidFils1  == 0) {/* fils1 */
					
					pipe(q);
					pidFils2 = fork();
				
					if (pidFils2  ==  -1) {
						printf("Erreur fork\n");
						exit (1);
					}

					if (pidFils2  == 0) {/* fils2 */
						dup2(q[1],1);
						close(q[0]);
						execlp("who","who",NULL);
						
			     			perror("ECHEC");
						exit(2);

					}else {/* p`ere2 */
						dup2(q[0],0);
						close(q[1]);
						dup2(p[1],1);
						close(p[0]);
						execlp("grep","grep",argv[1],NULL);
					}

		     			perror("ECHEC");
					exit(1);
				}else{
					dup2(p[0],0);
					close(p[1]);
					execlp("wc","wc","-l",NULL);
				}
				return EXIT_SUCCESS;
}
