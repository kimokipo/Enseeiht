#include <fcntl.h> 
#include <stdio.h>    /* printf */
#include  <stdlib.h>
#include <unistd.h>
	
	
void verifier_error(int descripteur, int type){
	if (descripteur == -1){
		if (type == 1){
			perror("Echec dans write");
		
		}else{
			perror("Echec dans la fermeture de fichier temp.txt");
		
		}
	}
}

int main(int argc,char *argv[]) {
	int fichier,entier,Nb_octects_lus,Nb_octects_ecrits,error_close;
	char tampon[1];
	entier = 1;
	Nb_octects_lus = 1;
	fichier  = open("temp.txt" ,O_WRONLY | O_CREAT | O_TRUNC,0600);
	
	if (fichier != -1){
		printf("l'ouverture du fichier temp.txt en mode écriture est réussie, le numéro du descripteur est : %d\n", fichier);
		
	}else{
		perror("Echec de l'ouverture du fichier temp.txt");
	}
	while(entier < 31){
		tampon[1] = (char) entier;
		
		if(entier%10 == 1 ){
			lseek(fichier,Nb_octects_lus , SEEK_SET);
		}
		Nb_octects_ecrits = write(fichier, tampon, Nb_octects_lus);
		sleep(1);
		entier = entier +1;
		verifier_error(Nb_octects_ecrits,1);
	}
	error_close = close (fichier);
	verifier_error(error_close,2);
	
}
