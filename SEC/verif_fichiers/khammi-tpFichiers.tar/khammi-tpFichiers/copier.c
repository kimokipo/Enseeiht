#include <fcntl.h> 
#include <stdio.h>    /* printf */
#include  <stdlib.h>
#include <unistd.h>
#define BUFSIZE 5
	
	
void verifier_error(int descripteur, int type){
	if (descripteur == -1){
		if (type == 0){
			perror("Echec dans read");
		}
		else if(type == 1){
			perror("Echec dans write");
		}else if(type == 2){
			perror("Echec dans la fermeture de fichier 1");
		}else{
			perror("Echec dans la fermeture de fichier 2");
		}
	}
}

int main(int argc,char *argv[]) {
	int fichier1, fichier2,Nb_octects_lus,Nb_octects_ecrits,error_close1,error_close2;
	char tampon[BUFSIZE];
	fichier1 = open(argv[1] ,O_RDONLY);
	fichier2  = open(argv[2] ,O_WRONLY | O_CREAT | O_TRUNC,0600);
	if (fichier1 != -1){
		printf("l'ouverture du fichier 1 en mode lecture est réussie , le numero du descripteur est : %d\n", fichier1);
		
	}else{
		perror("Echec de l'ouverture du fichier 1");
	}
	if (fichier2 != -1){
		printf("l'ouverture du fichier 2 en mode écriture est réussie, le numero du descripteur est : %d\n", fichier2);
		
	}else{
		perror("Echec de l'ouverture du fichier 2");
	}
	Nb_octects_lus = read(fichier1,tampon,  BUFSIZE);
	Nb_octects_ecrits = write(fichier2, tampon, Nb_octects_lus);
	while(Nb_octects_lus != 0){
		Nb_octects_lus = read(fichier1,tampon,  BUFSIZE);
		verifier_error(Nb_octects_lus,0);
		Nb_octects_ecrits = write(fichier2, tampon, Nb_octects_lus);
		verifier_error(Nb_octects_ecrits,1);
	}
	error_close1 = close (fichier1);
	verifier_error(error_close1,2);
	error_close2 = close (fichier2);
	verifier_error(error_close2,3);
	
}
