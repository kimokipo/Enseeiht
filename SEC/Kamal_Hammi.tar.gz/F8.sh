cat fichier | tr -dc aeiouy | wc -c
