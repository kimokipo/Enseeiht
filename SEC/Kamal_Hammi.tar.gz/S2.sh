x="j"
until [ $x = "o" ] || [ $x = "n" ]
do
    echo Etes-vous satisfait? \(o/n\)
    read x
done

