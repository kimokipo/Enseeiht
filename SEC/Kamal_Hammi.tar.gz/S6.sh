function {
        -v -o $3 -S -I -x
}

