ls ./*/*.o | wc -l
