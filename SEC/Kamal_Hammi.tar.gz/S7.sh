function inv {
    sort -r $1
}
