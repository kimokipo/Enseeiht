export default {
    groupLink: 'https://www.facebook.com/groups/115529558483490/search/?q=laura%20lalachante',
    scrollLength: 3000
}