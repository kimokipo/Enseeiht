    import java.awt.*;
	import java.applet.*;

	public class AppletBonjour extends Applet {

	 public void paint(Graphics g) {
	  g.drawString("Bonjour le monde !", 20, 20);
	 }
 
	}
