import logo from './logo.svg';
import './App.css';
import mysql from 'mysql';
function App(){
	return (
		<div className="App-header">
		 <header className="App-header">
		  console.log(1);
		</header>
		</div>
	);
}
