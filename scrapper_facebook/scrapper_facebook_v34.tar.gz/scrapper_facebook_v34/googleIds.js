export default {
        login: 'data.lalachante@gmail.com',
        password: 'x,kl;Xl;!xA9'
}
