export default [
	'https://www.facebook.com/groups/115529558483490/user/100049388292067'
]
