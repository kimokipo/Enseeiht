export default
[
  {
    "name": "fr",
    "value": "1OcJHHXnB88rxzmQl.AWXt65XxUMkbzguIzb33g6XpuB4.BhDrmv.M_.AAA.0.0.BhDrnl.AWXf_7L_MoI",
    "domain": ".facebook.com",
    "path": "/",
    "expires": 1636131039.909587,
    "size": 84,
    "httpOnly": true,
    "secure": true,
    "session": false,
    "sameSite": "None"
  },
  {
    "name": "xs",
    "value": "23%3ATzvxD-1y9sZ3dQ%3A2%3A1628355048%3A-1%3A11764",
    "domain": ".facebook.com",
    "path": "/",
    "expires": 1659891044.909572,
    "size": 51,
    "httpOnly": true,
    "secure": true,
    "session": false,
    "sameSite": "None"
  },
  {
    "name": "sb",
    "value": "5bkOYTjccGMX78QvaZonNGR5",
    "domain": ".facebook.com",
    "path": "/",
    "expires": 1691427049.90953,
    "size": 26,
    "httpOnly": true,
    "secure": true,
    "session": false,
    "sameSite": "None"
  },
  {
    "name": "locale",
    "value": "fr_FR",
    "domain": ".facebook.com",
    "path": "/",
    "expires": 1628959791.106303,
    "size": 11,
    "httpOnly": false,
    "secure": true,
    "session": false,
    "sameSite": "None"
  },
  {
    "name": "c_user",
    "value": "100055901680631",
    "domain": ".facebook.com",
    "path": "/",
    "expires": 1659891044.90955,
    "size": 21,
    "httpOnly": false,
    "secure": true,
    "session": false,
    "sameSite": "None"
  },
  {
    "name": "wd",
    "value": "801x601",
    "domain": ".facebook.com",
    "path": "/",
    "expires": 1628959840,
    "size": 9,
    "httpOnly": false,
    "secure": true,
    "session": false,
    "sameSite": "Lax"
  },
  {
    "name": "dpr",
    "value": "0.9999999916180968",
    "domain": ".facebook.com",
    "path": "/",
    "expires": 1628959849,
    "size": 21,
    "httpOnly": false,
    "secure": true,
    "session": false,
    "sameSite": "None"
  },
  {
    "name": "datr",
    "value": "oLkOYcecGbDGReC5F8q8W_uH",
    "domain": ".facebook.com",
    "path": "/",
    "expires": 1691426981.706275,
    "size": 28,
    "httpOnly": true,
    "secure": true,
    "session": false,
    "sameSite": "None"
  }
]
