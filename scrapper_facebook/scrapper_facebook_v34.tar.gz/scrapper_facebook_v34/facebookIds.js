export default {
    kamal: {login: 'kamel_hmo@hotmail.com', password: 'klmKLM123'},
	laura: {login: 'lalachante.reseaux@gmail.com', password: '$x5b1rZ2'},
	aurore: {login: 'chrismad31200@gmail.com', password: 'eza748!!!'}
}
