include("Lagrangien_Augmente.jl")
@doc doc"""
Résolution des problèmes de minimisation sous contraintes d'inégalités 

# Syntaxe
```julia
Lagrangien_Augmente_Inegalite(algo,fonc,contrainte,gradfonc,hessfonc,grad_contrainte,
			hess_contrainte,x0,options)
```

# Entrées
  * **algo** 		   : (String) l'algorithme sans contraintes à utiliser:
    - **"newton"**  : pour l'algorithme de Newton
    - **"cauchy"**  : pour le pas de Cauchy
    - **"gct"**     : pour le gradient conjugué tronqué
  * **fonc** 		   : (Function) la fonction à minimiser
  * **contrainte**	   : (Function) la contrainte [x est dans le domaine des contraintes ssi ``c(x)<0``]
  * **gradfonc**       : (Function) le gradient de la fonction
  * **hessfonc** 	   : (Function) la hessienne de la fonction
  * **grad_contrainte** : (Function) le gradient de la contrainte
  * **hess_contrainte** : (Function) la hessienne de la contrainte
  * **x0** 			   : (Array{Float,1}) la première composante du point de départ du Lagrangien
  * **options**		   : (Array{Float,1})
    1. **epsilon** 	   : utilisé dans les critères d'arrêt
    2. **tol**         : la tolérance utilisée dans les critères d'arrêt
    3. **itermax** 	   : nombre maximal d'itération dans la boucle principale
    4. **lambda0**	   : la deuxième composante du point de départ du Lagrangien
    5. **mu0,tho** 	   : valeurs initiales des variables de l'algorithme

# Sorties
* **xmin**		   : (Array{Float,1}) une approximation de la solution du problème avec contraintes d'inegalité
* **fxmin** 	   : (Float) ``f(x_{min})``
* **flag**		   : (Integer) indicateur du déroulement de l'algorithme
   - **0**    : convergence
   - **1**    : nombre maximal d'itération atteint
   - **(-1)** : une erreur s'est produite
* **niters** 	   : (Integer) nombre d'itérations réalisées

# Exemple d'appel
```julia
using LinearAlgebra
f(x)=100*(x[2]-x[1]^2)^2+(1-x[1])^2
gradf(x)=[-400*x[1]*(x[2]-x[1]^2)-2*(1-x[1]) ; 200*(x[2]-x[1]^2)]
hessf(x)=[-400*(x[2]-3*x[1]^2)+2  -400*x[1];-400*x[1]  200]
algo = "gct" # ou newton|gct
x0 = [1; 0]
options = []
contrainte(x) =  (x[1]^2) + (x[2]^2) -1.5
grad_contrainte(x) = [2*x[1] ;2*x[2]]
hess_contrainte(x) = [2 0;0 2]
output = Lagrangien_Augmente_Inegalite(algo,f,contrainte,gradf,hessf,grad_contrainte,hess_contrainte,x0,options)
```
"""
function Lagrangien_Augmente_Inegalite(algo,fonc::Function,contrainte::Function,gradfonc::Function,
	hessfonc::Function,grad_contrainte::Function,hess_contrainte::Function,x0,options)

    n = length(x0)
	if options == []
		epsilon = 1e-8
		tol = 1e-5
		itermax = 1000
		lambda0 = 2
		mu0 = 100
		tho = 2
	else
		epsilon = options[1]
		tol = options[2]
		itermax = options[3]
		lambda0 = options[4]
		mu0 = options[5]
		tho = options[6]
	end
	    nfonc(x) = fonc(x[1:n]) + 1/2 * norm( contrainte(x[1:n]) + x[n+1])^2
	    ngradfonc(x) = [gradfonc(x[1:n]) + contrainte(x[1:n])*grad_contrainte(x[1:n]);x[n+1]]
	    nhessfonc(x) = [hessfonc(x[1:n]) + contrainte(x[1:n])*hess_contrainte(x[1:n])+ grad_contrainte(x[1:n])*transpose(grad_contrainte(x[1:n])) zeros(n,1); zeros(1,n) 1]
	    ncontrainte(x) = contrainte(x[1:n]) + x[n+1]
	    ngrad_contrainte(x) = [grad_contrainte(x[1:n]) ; 1]
	    nhess_contrainte(x) = [hess_contrainte(x[1:n]) zeros(n,1); zeros(1,n) 0]
        xmin,fxmin,flag,iter = Lagrangien_Augmente(algo,nfonc,ncontrainte,ngradfonc,nhessfonc,ngrad_contrainte,
			nhess_contrainte,[x0;0],options)
	return xmin,fxmin,flag,iter
end
