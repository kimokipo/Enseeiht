#' # OPTINUM-RAPPORT
#'
#' Nom et Prénom                       Groupe:
#'
#' Date:
using LinearAlgebra
using Optinum

#' ## Exercice 1 - <le sujet de l'exercice>

function question1()

  print("TODO !")

  return
  
end

question1()

# Un commentaire sur l'exercice 1
