# Optinum - Méthodes numériques pour les problèmes d’optimisation

Le package [TestOptinum](https://github.com/mathn7/TestOptinum) contient les tests du TP-projet d’Optimisation Numérique pour l’année 2020-2021 de l'École INP-ENSEEIHT.

###### Auteurs : O.Cots, J. Gergaud, S. Gratton, P. Matalon, C. Royer, D. Ruiz et E. Simon
